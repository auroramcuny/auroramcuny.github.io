async function fetchAndDisplayData(neighborhood, treeType) {
    try {
        const response = await fetch('treesCDN.json');
        const data = await response.json();

        const filteredTrees = data.filter(tree => 
            tree.nta_name && tree.spc_common &&
            tree.nta_name.toLowerCase() === neighborhood.toLowerCase() && 
            tree.spc_common.toLowerCase() === treeType.toLowerCase()
        );

        const treeCount = filteredTrees.length;

        console.log(`Total number of trees: ${treeCount}`);
        document.getElementById('treeCount').textContent = `${neighborhood} has ${treeCount} ${treeType} trees.`;

        // Get count of all trees of the specified type for all of NYC
        // const maxNYC = data.filter(tree => 
        //             tree.spc_common && tree.spc_common.toLowerCase() === treeType.toLowerCase()
        //         ).length;
        //         console.log(`Total number of ${treeType} trees in NYC: ${maxNYC}`);

        // Get the borough of the selected neighborhood
        const selectedBorough = filteredTrees.length > 0 ? filteredTrees[0].borough : null;

        // Get count of all trees of the specified type in the selected borough
        const maxBoro = selectedBorough ? data.filter(tree => 
            tree.borough && tree.spc_common &&
            tree.borough.toLowerCase() === selectedBorough.toLowerCase() &&
            tree.spc_common.toLowerCase() === treeType.toLowerCase()
        ).length : 0;

        console.log(`Total number of ${treeType} trees in ${selectedBorough}: ${maxBoro}`);

        document.getElementById('percentageRisk').textContent = `You are ${Math.round((treeCount / maxBoro) * 100)}% more likely to sneeze in ${neighborhood} than in the rest of ${selectedBorough}.`; 
    } catch (error) {
        console.error('Error fetching or processing data:', error);
    }

}


document.getElementById('submit').addEventListener('click', event => {
    console.log("Submit button clicked");
    event.preventDefault();
    const selectedNeighborhood = document.getElementById('ntaDropdown').value;
    const selectedTree = document.getElementById('treeDropdown').value;

    console.log(`Neighborhood: ${selectedNeighborhood}`);
    console.log(`Tree Type: ${selectedTree}`);

    fetchAndDisplayData(selectedNeighborhood, selectedTree);
});